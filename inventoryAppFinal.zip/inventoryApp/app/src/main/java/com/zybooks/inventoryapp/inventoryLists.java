package com.zybooks.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class inventoryLists extends AppCompatActivity {

    private static final String TAG = "InventoryList";
    private List<inventoryItem> itemsListOptions;

    database database;
    RecyclerView itemsListView;
    TextView emptyListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        setContentView(R.layout.inventory_list);

        database = com.zybooks.inventoryapp.database.getInstance(getApplicationContext());
        itemsListOptions = database.getItems();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        itemsListView = findViewById(R.id.itemListView);
        itemsListView.setLayoutManager(layoutManager);

        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(itemsListView.getContext(),
                layoutManager.getOrientation());

        itemsListView.addItemDecoration(dividerItemDecoration);
        emptyListView = findViewById(R.id.emptyListView);

        inventoryActions adapter = new inventoryActions(itemsListOptions, this, database);
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                isListEmptyView();
            }
        });

        itemsListView.setAdapter(adapter);

        isListEmptyView();
    }

    @Override
    // Menu bar view
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.burger_button, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        switch (item.getItemId()) {
            case R.id.add_new:
                Log.d(TAG, "New item view");
                intent = new Intent(getApplicationContext(), editInventoryItems.class);
                startActivity(intent);
                return true;

            case R.id.sms_notification_toggle:
                Log.d(TAG, "SMS Notifications view");
                intent = new Intent(getApplicationContext(), smsNotifications.class);
                startActivity(intent);
                return true;

            case R.id.logout:
                Log.d(TAG, "Logging out");
                intent = new Intent(getApplicationContext(), mainLogin.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    
    // Allows user to view list if available 
    public void isListEmptyView() {
        Log.d(TAG, "Inventory size: " + itemsListOptions.size());
        if (itemsListOptions.isEmpty()) {
            itemsListView.setVisibility(View.GONE);
            emptyListView.setVisibility(View.VISIBLE);
        } else {
            itemsListView.setVisibility(View.VISIBLE);
            emptyListView.setVisibility(View.GONE);
        }
    }
}