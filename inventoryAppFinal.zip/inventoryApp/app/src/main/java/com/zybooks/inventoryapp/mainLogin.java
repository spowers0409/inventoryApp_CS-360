package com.zybooks.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;

public class mainLogin extends AppCompatActivity {

    // Create database for user login and password
    database database;

    EditText userInput;         // Input bar for username
    EditText passInput;         // Input bar for password
    Button loginButton;         // Login button
    Button registerButton;      // Register new user button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_login);

        database = com.zybooks.inventoryapp.database.getInstance(this); // Get instance of database

        userInput = findViewById(R.id.usernameInput);
        passInput = findViewById(R.id.passwordInput);
        userInput.addTextChangedListener(inputChanges);
        passInput.addTextChangedListener(inputChanges);

        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
        loginButton.setEnabled(false);                                  // Login button not enable by default
        registerButton.setEnabled(false);                               // Register button not enable by default


    }

    // Login and register buttons become available after input is added to both
    private final TextWatcher inputChanges;

    {
        inputChanges = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                boolean fieldsAreEmpty = getUsername().isEmpty() || getPassword().isEmpty();
                loginButton.setEnabled(!fieldsAreEmpty);
                registerButton.setEnabled(!fieldsAreEmpty);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
    }

    // Error message if username or password is incorrect
    public void login(View view) {
        if (validCredentials()) {
            showError(view.getContext().getResources().getString(R.string.invalid_login));
            return;
        }

        try {
            boolean isLoggedIn = database.checkUser(getUsername(), hash(getPassword()));

            if (isLoggedIn) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.invalid_login));
            }
        } catch (Exception e) {
            showError(view.getContext().getResources().getString(R.string.invalid_login));
        }
    }

    // Register new user if there is no current user
    public void register(View view) {
        if (validCredentials()) {
            showError(view.getContext().getResources().getString(R.string.existing_login));
        }

        try {
            boolean userCreated = database.addUser(getUsername(), hash(getPassword()));

            if (userCreated) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.existing_login));
            }
        } catch (Exception e) {
            showError(view.getContext().getResources().getString(R.string.existing_login));
        }
    }

    // Allow user with valid credentials to view the inventory list
    private void handleLoggedInUser() {
        Intent intent = new Intent(getApplicationContext(), inventoryLists.class);
        startActivity(intent);
    }
    private boolean validCredentials() {
        return getUsername().isEmpty() || getPassword().isEmpty();
    }

    // Get and return the username and password from input box
    private String getUsername() {
        Editable username = userInput.getText();
        return username != null ? username.toString().trim().toLowerCase() : "";
    }
    private String getPassword() {
        Editable password = passInput.getText();
        return password != null ? password.toString().trim() : "";
    }

    // Use MD5 to encrypt password
    private String hash(String password) throws Exception {
        MessageDigest passEncrypt = MessageDigest.getInstance("MD5");
        passEncrypt.update(password.getBytes());
        byte[] digest = passEncrypt.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        return sb.toString();
    }

    private void showError(String errorMessage) {
        Toast toast = Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, -200);
        toast.show();
    }
}