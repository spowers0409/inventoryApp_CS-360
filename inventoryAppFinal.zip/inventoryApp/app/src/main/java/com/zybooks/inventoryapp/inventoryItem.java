package com.zybooks.inventoryapp;

import java.io.Serializable;
// Serializable to convert item state to a byte stream
// which can then be converted back into a copy of the data
public class inventoryItem implements Serializable {
    private long inventoryID;
    private String inventoryName;
    private int inventoryQuantity;

    public inventoryItem() {
    }

    public inventoryItem(long id, String name) {
        inventoryID = id;
        inventoryName = name;
        inventoryQuantity = 0;
    }

    public inventoryItem(long id, String name, int quantity) {
        inventoryID = id;
        inventoryName = name;
        inventoryQuantity = quantity;
    }

    // Getter and setter for inventoryID
    public long getId() {
        return inventoryID;
    }
    public void setId(long id) {
        this.inventoryID = id;
    }

    // Getter and setter for inventoryName
    public String getName() {
        return inventoryName;
    }
    public void setName(String name) {
        this.inventoryName = name;
    }

    // Getter and setter for inventoryQuantity
    // Setter also sets the minimum number of quantity to 0
    public int getQuantity() {
        return inventoryQuantity;
    }
    public void setQuantity(int quantity) {
        this.inventoryQuantity = Math.max(0, quantity);
    }

    // incrementQuantity and decrementQuantity of inventoryQuantity by only 1 at a time
    public void incrementQuantity() {
        this.inventoryQuantity++;
    }
    public void decrementQuantity() {
        this.inventoryQuantity = Math.max(0, this.inventoryQuantity - 1);
    }
}