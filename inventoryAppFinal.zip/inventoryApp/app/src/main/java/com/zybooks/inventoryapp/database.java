package com.zybooks.inventoryapp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class database extends SQLiteOpenHelper {

    private static final String LOG = "InventoryDatabase";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "inventoryApp.db";
    private static database sDatabase;


    public static database getInstance(Context context) {
        Log.i(LOG, "Get instance of database");
        if (sDatabase == null) {
            sDatabase = new database(context);
        }
        return sDatabase;
    }

    private database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Database structure for inventory items
    private static final class itemsTable {
        private static final String TABLE_NAME = "inventory";
        private static final String COLUMN_NAME_ID = "_id";
        private static final String COLUMN_NAME_NAME = "name";
        private static final String COLUMN_NAME_QUANTITY = "quantity";
    }

    // Database structure for user login information
    private static final class usersTable {
        private static final String TABLE_NAME = "users";
        private static final String COLUMN_NAME_ID = "_id";
        private static final String COLUMN_NAME_USERNAME = "username";
        private static final String COLUMN_NAME_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(LOG, "Create database");
        db.execSQL("CREATE TABLE " + itemsTable.TABLE_NAME + " (" +
                itemsTable.COLUMN_NAME_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                itemsTable.COLUMN_NAME_NAME + " TEXT, " +
                itemsTable.COLUMN_NAME_QUANTITY + " INTEGER)");
        db.execSQL("CREATE TABLE " + usersTable.TABLE_NAME + " (" +
                usersTable.COLUMN_NAME_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                usersTable.COLUMN_NAME_USERNAME + " TEXT, " +
                usersTable.COLUMN_NAME_PASSWORD + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + usersTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + itemsTable.TABLE_NAME);
        onCreate(db);
    }

    // Return a list of all items in inventory database
    public List<inventoryItem> getItems() {
        List<inventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + itemsTable.TABLE_NAME;
        Cursor cursor = db.rawQuery(sql, new String[]{});
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                int quantity = cursor.getInt(2);
                items.add(new inventoryItem(id, name, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return items;
    }

    public boolean addUser(String username, String password) {
        // If username exists, please login
        if (usernameExists(username)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        // Insert values of username and password
        ContentValues values = new ContentValues();
        values.put(usersTable.COLUMN_NAME_USERNAME, username);
        values.put(usersTable.COLUMN_NAME_PASSWORD, password);
        long userId = db.insert(usersTable.TABLE_NAME, null, values);

        return userId != -1;
    }

    // Method to verify if a username and password exist in the database
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM " + usersTable.TABLE_NAME + " WHERE username = ? AND password = ?";

        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        return cursor.getCount() > 0;
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM " + usersTable.TABLE_NAME + " WHERE username = ?";

        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[]{username});

        return cursor.getCount() > 0;
    }

    // Method to add inventory items to database
    public boolean addItem(String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(itemsTable.COLUMN_NAME_NAME, name);
        values.put(itemsTable.COLUMN_NAME_QUANTITY, quantity);

        long itemId = db.insert(itemsTable.TABLE_NAME, null, values);

        return itemId != -1;
    }

    // Method to make updates to existing items in database
    public boolean updateItem(inventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(itemsTable.COLUMN_NAME_NAME, item.getName());
        values.put(itemsTable.COLUMN_NAME_QUANTITY, item.getQuantity());

        int rowsUpdated = db.update(itemsTable.TABLE_NAME, values, itemsTable.COLUMN_NAME_ID + " = ?",
                new String[]{String.valueOf(item.getId())});

        return rowsUpdated > 0;
    }

    // Method to remove items from database
    public boolean deleteItem(inventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();

        int rowsDeleted = db.delete(itemsTable.TABLE_NAME, itemsTable.COLUMN_NAME_ID + " = ?",
                new String[]{String.valueOf(item.getId())});

        return rowsDeleted > 0;
    }
}
