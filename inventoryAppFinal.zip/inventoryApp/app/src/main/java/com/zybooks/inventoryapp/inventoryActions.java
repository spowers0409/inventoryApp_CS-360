package com.zybooks.inventoryapp;

import static com.zybooks.inventoryapp.R.*;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class inventoryActions extends RecyclerView.Adapter<inventoryActions.ItemHolder> {
    private static final String TAG = "ItemAdapter";
    private final List<inventoryItem> inventoryItems;
    private final Context itemContext;

    database database;

    public inventoryActions(List<inventoryItem> items, Context context, database inventoryDatabase) {
        inventoryItems = items;
        itemContext = context;
        database = inventoryDatabase;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(layout.new_inventory_item, parent, false);
        return new ItemHolder(view, database);
    }

    @SuppressLint({"NonConstantResourceId", "NotifyDataSetChanged"})
    @Override
    public void onBindViewHolder(ItemHolder holder, @SuppressLint("RecyclerView") int position) {
        inventoryItem item = inventoryItems.get(position);
        holder.bindItem(item);

        holder.actionsButtons.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(itemContext, holder.actionsButtons);
            popup.inflate(menu.burger_button_options);
            popup.setOnMenuItemClickListener(menuItem -> {
                switch (menuItem.getItemId()) {
                    case id.menu_edit:
                        Log.i(TAG, "edit item at position " + position);

                        Intent intent = new Intent(itemContext, editInventoryItems.class);
                        intent.putExtra(editInventoryItems.EXTRA_ITEM, item);
                        itemContext.startActivity(intent);

                        return true;
                    case id.menu_remove:
                        Log.i(TAG, "remove item at position " + position);

                        new AlertDialog.Builder(itemContext).setIcon(android.R.drawable.ic_dialog_alert)
                                .setTitle(string.delete_confirmation_title).setMessage(string.delete_confirmation)
                                .setPositiveButton("Yes", (dialog, which) -> {
                                    boolean deleted = database.deleteItem(item);
                                    if (deleted) {
                                        inventoryItems.remove(position);
                                        notifyItemRemoved(position);
                                        notifyDataSetChanged();
                                    } else {
                                        Toast.makeText(itemContext, string.delete_error, Toast.LENGTH_SHORT).show();
                                    }
                                }).setNegativeButton("No", null).show();

                        return true;
                    default:
                        return false;
                }
            });
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }


    static class ItemHolder extends RecyclerView.ViewHolder {

        private inventoryItem childItemView;
        private final TextView childNameView;
        private final EditText childQuantityView;

        // Instance of the database
        database database;
        ImageButton increaseButton;
        ImageButton decreaseButton;
        ImageButton actionsButtons;

        public ItemHolder(View itemView, database inventoryDb) {
            super(itemView);
            database = inventoryDb;

            childNameView = itemView.findViewById(id.itemName);
            childQuantityView = itemView.findViewById(id.editQuantity);

            increaseButton = itemView.findViewById(id.increaseButton);
            decreaseButton = itemView.findViewById(id.decreaseButton);
            actionsButtons = itemView.findViewById(id.actionsButtons);

            // Update the quantity to increment +1 when action button is clicked
            increaseButton.setOnClickListener(v -> {
                childItemView.incrementQuantity();
                boolean updated = database.updateItem(childItemView);
                if (updated) {
                    childQuantityView.setText(String.valueOf(childItemView.getQuantity()));
                }
            });

            // Update the quantity to decrement -1 when action button is clicked
            decreaseButton.setOnClickListener(v -> {
                childItemView.decrementQuantity();
                boolean updated = database.updateItem(childItemView);
                if (updated) {
                    childQuantityView.setText(String.valueOf(childItemView.getQuantity()));
                }
            });



            // Apply changes to database when updates are saved
            childQuantityView.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                    childItemView.setQuantity(convertItem());
                    boolean updated = database.updateItem(childItemView);
                    Log.d(TAG, "Update successful: " + updated);

                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        }

        // Bind item
        public void bindItem(inventoryItem item) {
            childItemView = item;
            Log.d("ItemHolder", "Bind item: " + childItemView.getName());
            childNameView.setText(childItemView.getName());
            childQuantityView.setText(String.valueOf(childItemView.getQuantity()));
        }

        // Convert input to integer
        private int convertItem() {
            String rawValue = childQuantityView.getText().toString().replaceAll("[^\\d.]", "").trim();
            int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

            // Max least amount possible is 0
            return Math.max(quantity, 0);
        }
    }
}